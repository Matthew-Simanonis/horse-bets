# horse-bets

Simple horse betting program, requested by my father. Takes in the 4-race history of a horse, and whether it has the same jockey that day.
Calculates points based on history. 1 point for 3rd, 2 points for 2nd, 3 points for 1st. 

Flask backend with mostly javascript to do calculations in the browser. This was mostly for practice with javascript and web apps in general.
Still needs lots of work. 

Let me know if there are any critiques you have of my code.

Thanks